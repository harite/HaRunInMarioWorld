<?php
date_default_timezone_set('Asia/Shanghai');
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/>
		<title>Biolab Disaster - Kilofox.Net</title>
		<style>
			body {
				background-color: #25272b;
				color: #fff;
				font-family: arial;
				margin: 40px auto 60px auto;
				width: 480px;
				font-size: 12pt;
			}
			a {
				color: #F47920;
				text-decoration: none;
			}
			a:hover {
				color: #ff9536;
				text-shadow: #F47920 0px 0px 2px;
			}
			h1 {
				font-size: 140%;
				margin: 2.5em 0 0 0;
			}
			#canvas {
				width: 480px;
				height: 320px;
				border: 1px solid #3b3d42;
				image-rendering: optimizeSpeed;
				-webkit-interpolation-mode: nearest-neighbor;
			}
			#noCanvas {
				padding: 90px 32px;
				font-weight: bold;
				border: 1px solid #3b3d42;
				background-color: #000;
			}
			#ad {
				width: 160px;
				height: 600px;
				position: absolute;text-align: center;
				left: 32px;
				top: 0;
				bottom: 0;
				margin: auto;
			}
		</style>
		<script src="lib/impact/impact.js"></script>
		<?php if ( isset($_GET['debug']) ): ?>
			<script src="lib/game/biolab_debug.js"></script>
		<?php else: ?>
			<script src="lib/game/biolab.js"></script>
		<?php endif; ?>
	<!--<script src="game.min.js"></script>-->
	</head>
	<body>
		<div id="ad">
			<script>
				<!--
				google_ad_client = "ca-pub-3247088052200757";
				google_ad_slot = "5601075039";
				google_ad_width = 160;
				google_ad_height = 600;
				//-->
			</script>
			<script src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
		</div>
		<canvas id="canvas">
			<div id="noCanvas">
				<p>您的浏览器不支持 HTML5。</p>
				<p>您需要有一个好一点儿的浏览器，比如：
					<a href="http://www.google.com/chrome/" target="_blank">Chrome</a> 或
					<a href="http://www.mozilla.com/firefox/" target="_blank">Firefox</a>。
				</p>
			</div>
		</canvas>
		<h1>Biolab Disaster</h1>
		<p>2015年9月21日更新</p>
		<p>Copyright &copy; 2005-<?php echo date('Y'); ?> <a href="http://www.kilofox.net" target="_blank">Kilofox.Net</a>. All rights reserved.</p>
	</body>
</html>