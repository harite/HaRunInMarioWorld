<?php
date_default_timezone_set('Asia/Shanghai');
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/>
		<title>Z-Type - Kilofox.Net</title>
		<style>
			body {
				background-color: #25272b;
				color: #fff;
				font-family: arial;
				margin: 0;
				padding: 0;
				font-size: 12pt;
			}
			#canvas {
				border: 1px solid #555;
				position: absolute;
				left: 0;
				top: 0;
				width: 360px;
				height: 640px;
				background-color: #000;
			}
			a {
				color: #F47920;
				text-decoration: none;
			}
			a:hover {
				color: #ff9536;
				text-shadow: #F47920 0px 0px 2px;
			}
			#game {
				position: absolute;
				left: 0;
				right: 0;
				top: 0;
				bottom: 0;
				margin: auto;
				width: 360px;
				height: 640px;
			}
			#nocanvas {
				width: 360px;
				margin: 150px auto;
			}
			#ad {
				width: 160px;
				height: 600px;
				position: absolute;text-align: center;
				left: 32px;
				top: 0;
				bottom: 0;
				margin: auto;
			}
			.powered-by-bootphp {
				position: absolute;
				text-align: center;
				bottom: 32px;
				right: 32px;
			}
		</style>
		<script src="lib/impact/impact.js"></script>
		<script src="lib/game/main.js"></script>
		<!--<script src="game.min.js"></script>-->
	</head>
	<body>
		<p class="powered-by-bootphp">
			Z-Type
			<br/><br/>2015年9月21日更新
			<br/><br/>Copyright &copy; 2005-<?php echo date('Y'); ?> <a href="http://www.kilofox.net" target="_blank">Kilofox.Net</a>.
			<br/>All rights reserved.
		</p>
		<div id="ad">
			<script>
				<!--
				google_ad_client = "ca-pub-3247088052200757";
				google_ad_slot = "5601075039";
				google_ad_width = 160;
				google_ad_height = 600;
				//-->
			</script>
			<script src="http://pagead2.googlesyndication.com/pagead/show_ads.js"></script>
		</div>
		<div id="game">
			<canvas id="canvas">
				<div id="noCanvas">
					<p>您的浏览器不支持 HTML5。</p>
					<p>您需要有一个好一点儿的浏览器，比如：
						<a href="http://www.google.com/chrome/" target="_blank">Chrome</a> 或
						<a href="http://www.mozilla.com/firefox/" target="_blank">Firefox</a>。
					</p>
				</div>
			</canvas>
		</div>
	</body>
</html>